qicli call ALTabletService.showImage http://198.18.0.1/apps/ucly/stupid_bot.png

read -p "Press enter to continue" -t 4

 qicli call ALAnimatedSpeech.say "Bonjour, vous êtes sur le point de commencer une interaction avec un robot. Ce robot a été programmé. Il n'est pas votre ami. Il n'est qu'un interface. Restez vigilant. En cas de doute, signaler son comportement. Ne dialoguer pas plus de 1h par jour avec votre robot. " null

 
 read -p "Press enter to continue" -t 10
 
qicli call ALTabletService.showImage http://198.18.0.1/apps/dance_date/img/Logo_CPE.jpg	