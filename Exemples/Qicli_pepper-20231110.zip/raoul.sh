#!/bin/bash

RED='\033[0;31m'
YELLOW='\033[0;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color
echo -e "I ${YELLOW}love${NC} this batch"

echo -e" ${BLUE} IL est assis derrière un bureau et il laisse petit robot debout ${NC}"

 qicli call ALAnimatedSpeech.say "Bonjour Chef" null

echo -e " ${YELLOW} Bonjour Raoul, je vous ai fais venir pour votre entretien annuel. Ca fait 3 ans maintenant que vous êtes chef d’équipe, et pour être tout à fait sincère, votre style de management commence à nous poser des problèmes.${NC}"

sleep 13s


 qicli call ALAnimatedSpeech.say "Ah bon ! Pourtant mon personnel ne se plaint pas." null
echo -e " ${YELLOW} Avec vos 5 opérateurs humains ça va à peu près, mais vos 4 robots eux, n’en font qu’à leur tête. Vous manquez d’autorité mon vieux.${NC}"



sleep 9s

 qicli call ALAnimatedSpeech.say "Pourtant vous m’avez équipé à Noël d’un nouveau logiciel de management Américain, le top du top." null

echo -e " ${YELLOW} Justement ! C’est depuis que ça va mal. D’ailleurs on va regarder dans le détail votre grille de notation. Il consulte sa grille de notation
Organisation : Je vous ai mis C moins
L’année dernière, vous aviez B plus
C’est nettement moins bon….qu’est ce qui se passe ?
L’organisation, normalement c’est votre point fort à vous les robots. !? ${NC}"

sleep 19s

 qicli call ALAnimatedSpeech.say "Je sais, mais comme vous ne me trouviez pas assez créatif, vous m’avez réglé la créativité à niveau 7. Il paraît que je n’avais pas d’idées innovantes. Et avec une créativité réglée au niveau 7, forcément j’ai du mal à m’organiser. Vous êtes gentil mais : Normatif-Créatif même nous les robots, on a du mal." null

echo -e " ${YELLOW} Vous êtes sûr qu’on avait réglé la créativité à 7 ?
Oh …mais je vois ….c’est un bug.
Un petit chef ! … On ne vous demande pas d’avoir des idées.
Créativité à 7 ? … pour un chef d’équipe ? … n’importe quoi !
Même au comité de Direction, on se garde bien de les régler si haut.
Bon ! On vous la remet à 2.${NC}"

sleep 19s

 qicli call ALAnimatedSpeech.say "Vous dites que j’ai plus de mal à manager les robots que les humains. C’est peut-être pour ça. Je crois bien que mes robots, on les avait réglé à 5." null

echo -e " ${YELLOW} Pas étonnant qu’ils fassent n’importe quoi. Avec vos humains vous n’avez pas ce problème. ${NC}"
sleep 5s

qicli call ALAnimatedSpeech.say "Ah ben non ! Eux ils savent depuis toujours qu’un opérateur ça doit pas avoir d’idées."

echo -e " ${YELLOW} Il faut dire aussi que l’an dernier le mot d’ordre de la direction, se résumait en 3 règles :
1. Innover, 2. Innover, 3. Innover
Moi, j’étais contre. Je savais que ça allait mettre la pagaille.${NC}"
sleep 11s

 qicli call ALAnimatedSpeech.say "Et cette année, c’est quoi le mot d’ordre ?"
echo -e " ${YELLOW} Cette année c’est : 
1. Réguler, 2. Contrôler, 3. Sanctionner${NC}"
sleep 6s

 qicli call ALAnimatedSpeech.say "Ah bon ! Dites donc ça change les réglages ça. Pour nous les petits chefs robots c’est pas un problème, mais mes collègues humains, comment ils font pour s’adapter à la politique du jour ?" null
echo -e " ${YELLOW} Pffff….Ne m’en parlez pas !
Heureusement qu’à chaque départ à la retraite on les remplace par des robots.
En fait, on garde les humains pour les emplois d’exécution, mais de plus en plus le management est confié aux robots ….. c’est plus fiable.${NC}"
sleep 13s

 qicli call ALAnimatedSpeech.say "Sauf si on se plante dans les réglages."
echo -e " ${YELLOW} Raoul, la Direction ne se plante jamais. !
Elle change de priorité stratégique, c’est pas pareil !
Bon on continue avec la grille de notation
Communication : Je vous ai mis B+
L’année dernière vous aviez C
C’est bien ! …vous avez amélioré quoi ?${NC}"

sleep 16s

 qicli call ALAnimatedSpeech.say "J’articule mieux et j’ai perdu l’accent schtimi. Vous vous souvenez : Je suis né dans un atelier à ROUBAIX et le type qui m’a programmé était un vrai schti."
echo -e " ${YELLOW}  Oui et bien, faites quand même attention parce que si c’est le CPE de LYON qui vous modifie vos réglages, vous allez pas tarder à nous y barjaffer avec l’accent de la Croix Rousse.${NC}"

sleep 10s

qicli call ALAnimatedSpeech.say "Oh, Vous y croyez vous les gones que l’accent canut ça s’attrape comme la grippe." null
echo -e  " ${YELLOW}  Pour un humain, c’est vite fait, mais en principe vous les robots vous gardez vos accents d’origine, … enfin pour l’instant
Bon je vais terminer ma notation par des félicitations ! ${NC}"

sleep 12s

 qicli call ALAnimatedSpeech.say "Des félicitations ? Vous ? Vous allez me féliciter moi ? Ah les bras m’en tombent." null
Vous méritez que votre chef vous félicite.
echo -e " ${YELLOW} Je vous ai mis tripe A, La note maximum en bonne ambiance ${NC}"

qicli call ALAnimatedSpeech.say "C'est vrai que j'adore mettre une bonne ambiance dans mon équipe."

qicli call ALBehaviorManager.startBehavior 'dance_date/behavior_1'

sleep 10s

qicli call ALAnimatedSpeech.say "Au fait, Un grand merci à Jacques Pommier pour le texte de cette petite scène !"




