#!/bin/bash

RED='\033[0;31m'
YELLOW='\033[0;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color
echo -e "I ${YELLOW}love${NC} this batch"

echo -e" ${BLUE} robot pas loin a regarder"



read -p "Press enter to continue" -t 4

 qicli call ALAnimatedSpeech.say "Fabrice, tu sais je me sens un peu nul en ce moment , tout les robots du quartier ont plein de super pouvoir et moi  je n'évolue plus depuis quelques temps c'est vraiment nul ! " null
read -p "Press enter to continue, je comprends pas trop tu sais moi c'est pas trop mon truc la techno. Il faut faire une mise à jour ou un truc dans le genre" -t 8
 
 qicli call ALAnimatedSpeech.say "Il y a un super site avec des skinne  pour robot, c'est vraiment trop cool et tout le monde en a. Moi je flashe sur le skine robo guerle. Il est trop top  " null


 
read -p "C'est marrant et ca coute quoi" -t 4

	qicli call ALAnimatedSpeech.say "En fait c'est moins de un 30 roboboeque et si tu t'habonnes pour 1 euro par semaine, tu as droit à 200 roboboeque par mois et plein d'autre mise à jour"

	read -p "Je sais pas trop" -t 3
	
	qicli call ALAnimatedSpeech.say "T'inquiete pas c'est rien pour toi et tu veux pas être le seul à avoir un robot avec le skinne d'origine, tu vas passer pour un bolosse"

     read -p "Bon Ok" -t 4
	 
	qicli call ALAnimatedSpeech.say "Super l'abonnement est validé, je suis trop content, tu peux choisir de nouvelles dances pour moi maintenant, tu peux en prendre 2 ce mois ci avec les roboboeuque qu'il reste "


	 
	 read -p "Press enter to continue" -t 15
	

	 
		 read -p "choisis ce que tu veux " -t 5
		 
