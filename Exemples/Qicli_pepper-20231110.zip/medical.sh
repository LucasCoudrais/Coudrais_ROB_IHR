

qicli call ALTabletService.showImage http://198.18.0.1/apps/dance_date/img/Logo_CPE.jpg	

read -p "Press enter to continue" -t 10

 qicli call ALAnimatedSpeech.say "Je ne te trouve pas très en forme aujourd'hui. Ton exposé n'est pas très claire et les gens commencent à s'ennuier. Regarde il y en a même 1 ou 2 qui sont déjà partie. Tu as besoin d'aide " null

 read -p "J'ai besoin de repos et de sport , c'est ca " -t 8
 
 qicli call ALAnimatedSpeech.say "Oui, il n'y a pas que les pizzas dans la vie, ca c'est sûr, tu vois ce weekend tu as bien abusé"
 
 read -p "On va se clamer tout de suite" -t 10
 
 qicli call ALAnimatedSpeech.say "Le sport c'est bien mais ca ne va pas suffir sur la durée. J'ai bien étudié toute tes données et je pense qu'il te faut du tonic cerveau plusse. Les etudes me semblent suffisemment credible pour tenter , en tout cas c'est pas dangereux"
 
 
 
 


 qicli call ALTabletService.showImage http://198.18.0.1/apps/ucly/medecine_serious.jpg
  read -p "C'est pas trop mon truc tout ca " -t 8
  qicli call ALAnimatedSpeech.say "Je sais mais ne t'inquiéte pas, tu peux me faire confiance, je me soucis de toi et de ta santé"
   qicli call ALTabletService.showImage http://198.18.0.1/apps/ucly/medecine_green.jpg
  read -p "Ok , on va essayer, alors " -t 10
 
 qicli  call ALTabletService.showImage http://198.18.0.1/apps/dance_date/img/Logo_CPE.jpg	
 
   read -p "Ok , on va essayer, alors " -t 10
   
   qicli call ALBehaviorManager.startBehavior 'dance_date/behavior_1'
